package com.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage extends BasePage {

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "sso-frame")
    WebElement loginFrame;

    @FindBy(xpath = "//input[@placeholder='Mobile no.']")
    WebElement mobileNumber;

    @FindBy(xpath = "//button[text()='Continue']")
    WebElement continueBtn;

    public void switchToLoginFrame() {

        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(loginFrame));

    }

    public void enterMobileNumber(String mobile) {

        wait.until(ExpectedConditions.visibilityOf(mobileNumber));

        mobileNumber.clear();

        mobileNumber.sendKeys(mobile);

    }

    public void clickContinue() {
    	wait.until(ExpectedConditions.visibilityOf(continueBtn));
    	wait.until(ExpectedConditions.elementToBeClickable(continueBtn));

    	((JavascriptExecutor) driver).executeScript(
    	    "arguments[0].click();", continueBtn);

    }

    public void waitForOTPVerification() {

        wait.until(ExpectedConditions.invisibilityOfElementLocated(
                org.openqa.selenium.By.xpath("//div[text()='Enter OTP']")));

    }

    public void switchToDefaultContent() {

        driver.switchTo().defaultContent();

    }

    public boolean isLoginSuccessful() {

        return driver.getCurrentUrl().contains("ixigo");

    }

}