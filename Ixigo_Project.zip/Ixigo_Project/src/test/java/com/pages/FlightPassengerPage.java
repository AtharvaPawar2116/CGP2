package com.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class FlightPassengerPage extends BasePage {

    JavascriptExecutor js;

    public FlightPassengerPage(WebDriver driver) {
        super(driver);
        js = (JavascriptExecutor) driver;
    }

    @FindBy(xpath = "//input[contains(@placeholder,'Name') or contains(@name,'firstName')]")
    WebElement name;

    @FindBy(xpath = "//input[contains(@placeholder,'Age') or contains(@name,'age') or contains(@placeholder,'DOB')]")
    WebElement age;

    @FindBy(xpath = "//button[contains(text(),'Male') or contains(text(),'MALE')] | //label[contains(text(),'Male')]")
    WebElement male;

    @FindBy(xpath = "//input[contains(@id,'insurance') or contains(@class,'insurance')] | //div[contains(@class,'insurance')]//div")
    WebElement insurance;

    @FindBy(xpath = "//button[contains(text(),'Continue') or contains(text(),'Proceed') or contains(text(),'Pay')]")
    WebElement continueBtn;

    public boolean isPassengerPageDisplayed() {
        try {
            return wait.until(ExpectedConditions.visibilityOf(name)).isDisplayed();
        } catch (Exception e) {
            return driver.getCurrentUrl().contains("flight") || driver.getCurrentUrl().contains("booking");
        }
    }

    public void enterPassengerName(String passengerName) {

        wait.until(ExpectedConditions.elementToBeClickable(name));

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", name);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        name.clear();
        name.sendKeys(passengerName);
    }

    public void enterPassengerAge(String passengerAge) {

        try {
            wait.until(ExpectedConditions.elementToBeClickable(age));

            js.executeScript("arguments[0].scrollIntoView({block:'center'});", age);

            age.click();
            age.clear();
            age.sendKeys(passengerAge);

            if (age.getAttribute("value").isEmpty()) {
                js.executeScript("arguments[0].value=arguments[1];", age, passengerAge);
            }
        } catch (Exception e) {
            System.out.println("Age field skipped or not required: " + e.getMessage());
        }
    }

    public void selectGender() {

        try {
            wait.until(ExpectedConditions.elementToBeClickable(male));
            js.executeScript("arguments[0].click();", male);
        } catch (Exception e) {
            System.out.println("Gender selection skipped: " + e.getMessage());
        }

    }

    public void selectInsurance() throws InterruptedException {

        try {
            wait.until(ExpectedConditions.elementToBeClickable(insurance));

            js.executeScript("arguments[0].scrollIntoView({block:'center'});", insurance);
            Thread.sleep(2000);

            js.executeScript("arguments[0].click();", insurance);
        } catch (Exception e) {
            System.out.println("Insurance selection skipped: " + e.getMessage());
        }
    }

    public boolean isContinueButtonEnabled() {
        return continueBtn.isEnabled();
    }

    public void clickContinue() {

        wait.until(ExpectedConditions.elementToBeClickable(continueBtn));

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", continueBtn);

        js.executeScript("arguments[0].click();", continueBtn);

    }
}
